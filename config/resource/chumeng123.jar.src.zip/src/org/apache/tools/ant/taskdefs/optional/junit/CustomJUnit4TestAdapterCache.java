package org.apache.tools.ant.taskdefs.optional.junit;

import junit.framework.JUnit4TestAdapter;
import junit.framework.JUnit4TestAdapterCache;
import junit.framework.TestResult;
import org.junit.runner.Description;
import org.junit.runner.notification.Failure;
import org.junit.runner.notification.RunListener;
import org.junit.runner.notification.RunNotifier;

public class CustomJUnit4TestAdapterCache extends JUnit4TestAdapterCache {
   private static final CustomJUnit4TestAdapterCache INSTANCE = new CustomJUnit4TestAdapterCache();

   public static CustomJUnit4TestAdapterCache getInstance() {
      return INSTANCE;
   }

   private CustomJUnit4TestAdapterCache() {
   }

   public RunNotifier getNotifier(TestResult result, JUnit4TestAdapter adapter) {
      return this.getNotifier(result);
   }

   public RunNotifier getNotifier(final TestResult result) {
      final IgnoredTestResult resultWrapper = (IgnoredTestResult)result;
      RunNotifier notifier = new RunNotifier();
      notifier.addListener(new RunListener() {
         public void testFailure(Failure failure) throws Exception {
            result.addError(CustomJUnit4TestAdapterCache.this.asTest(failure.getDescription()), failure.getException());
         }

         public void testFinished(Description description) throws Exception {
            result.endTest(CustomJUnit4TestAdapterCache.this.asTest(description));
         }

         public void testStarted(Description description) throws Exception {
            result.startTest(CustomJUnit4TestAdapterCache.this.asTest(description));
         }

         public void testIgnored(Description description) throws Exception {
            if (resultWrapper != null) {
               resultWrapper.testIgnored(CustomJUnit4TestAdapterCache.this.asTest(description));
            }

         }

         public void testAssumptionFailure(Failure failure) {
            if (resultWrapper != null) {
               resultWrapper.testAssumptionFailure(CustomJUnit4TestAdapterCache.this.asTest(failure.getDescription()), failure.getException());
            }

         }
      });
      return notifier;
   }
}
